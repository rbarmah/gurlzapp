import React from 'react';
import LoginForm from './LoginForm/index';

// Re-export the main LoginForm component
export default LoginForm;